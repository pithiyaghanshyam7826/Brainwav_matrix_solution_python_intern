import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from datetime import datetime
import re

class InventoryManagementSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("Inventory Management System")
        self.root.geometry("1000x600")
        self.root.configure(bg="#ECEFF1")
        
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="inventory_db"
        )
        self.create_tables()
        
        self.username = "admin"
        self.password = "admin123"
        self.current_user = None
        
        self.show_login_screen()

    def create_tables(self):
        cursor = self.conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            quantity INT NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            min_stock INT NOT NULL
        )''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT,
            type VARCHAR(50),
            quantity INT,
            date DATETIME,
            FOREIGN KEY (product_id) REFERENCES products(id)
        )''')
        self.conn.commit()

    def show_login_screen(self):
        self.login_frame = ttk.Frame(self.root, style="Login.TFrame")
        self.login_frame.pack(expand=True, pady=100)
        
        style = ttk.Style()
        style.configure("Login.TFrame", background="#B0BEC5")
        style.configure("TLabel", background="#B0BEC5", foreground="#263238", font=("Poppins", 20))
        style.configure("TButton", font=("Poppins", 16, "bold"))
        style.configure("Accent.TButton", background="#26A69A", foreground="#000000")
        style.map("Accent.TButton", background=[("active", "#00695C")])
        style.configure("Dark.TEntry", fieldbackground="#CFD8DC", foreground="#263238", 
                       font=("Poppins", 20))

        ttk.Label(self.login_frame, text="Username :").grid(row=0, column=0, padx=20, pady=20)
        self.username_entry = ttk.Entry(self.login_frame, style="Dark.TEntry", width=30, font=("Poppins", 16, "bold"))
        self.username_entry.grid(row=0, column=1, padx=20, pady=20)
        
        ttk.Label(self.login_frame, text="Password :").grid(row=1, column=0, padx=20, pady=20)
        self.password_entry = ttk.Entry(self.login_frame, show="*", style="Dark.TEntry", width=30, font=("Poppins", 16, "bold"))
        self.password_entry.grid(row=1, column=1, padx=20, pady=20)
        
        ttk.Button(self.login_frame, text="Login", command=self.login, 
                  style="Accent.TButton").grid(row=2, column=0, columnspan=2, pady=30)

    def login(self):
        if (self.username_entry.get() == self.username and 
            self.password_entry.get() == self.password):
            self.current_user = self.username
            self.login_frame.destroy()
            self.show_main_interface()
        else:
            messagebox.showerror("Error", "Invalid credentials")

    def show_main_interface(self):
        style = ttk.Style()
        style.configure("TFrame", background="#ECEFF1")
        style.configure("TLabel", background="#ECEFF1", foreground="#263238", font=("Poppins", 14))
        style.configure("Accent.TButton", background="#26A69A", foreground="#000000", 
                       font=("Poppins", 12, "bold"))
        style.map("Accent.TButton", background=[("active", "#00695C")])
        style.configure("Treeview", font=("Poppins", 12), rowheight=30, 
                       background="#FFFFFF", foreground="#263238", fieldbackground="#FFFFFF")
        style.configure("Treeview.Heading", font=("Poppins", 14, "bold"), background="#B0BEC5", 
                       foreground="#263238")
        style.configure("Dark.TEntry", fieldbackground="#CFD8DC", foreground="#263238", 
                       font=("Poppins", 14))

        self.main_frame = ttk.Frame(self.root)
        self.main_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        
       
        self.main_frame.grid_rowconfigure(0, weight=0)  
        self.main_frame.grid_rowconfigure(1, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)
        
        entry_frame = ttk.LabelFrame(self.main_frame, text="Product Management", 
                                   style="Custom.TLabelframe")
        entry_frame.grid(row=0, column=0, sticky="ew", pady=5)
        style.configure("Custom.TLabelframe", background="#B0BEC5")
        style.configure("Custom.TLabelframe.Label", font=("Poppins", 16, "bold"), foreground="#263238")

        entry_frame.grid_columnconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=1)
        entry_frame.grid_rowconfigure((0, 1), weight=1)

        fields = [("Name:", 0), ("Quantity:", 2), ("Price:", 4), ("Min Stock:", 6)]
        self.entries = {}
        for label_text, col in fields:
            ttk.Label(entry_frame, text=label_text, style="Field.TLabel").grid(row=0, column=col, padx=5, pady=10, sticky="e")
            entry = ttk.Entry(entry_frame, style="Dark.TEntry")
            entry.grid(row=0, column=col+1, padx=5, pady=10, sticky="ew")
            self.entries[label_text.strip(":")] = entry
        
        self.name_entry = self.entries["Name"]
        self.quantity_entry = self.entries["Quantity"]
        self.price_entry = self.entries["Price"]
        self.min_stock_entry = self.entries["Min Stock"]
        
        style.configure("Field.TLabel", background="#B0BEC5", foreground="#263238")

        buttons = [
            ("Add Product", self.add_product, 0),
            ("Update Selected", self.update_product, 2),
            ("Delete Selected", self.delete_product, 4),
            ("Generate Report", self.generate_report, 6)
        ]
        for text, command, col in buttons:
            ttk.Button(entry_frame, text=text, command=command, 
                      style="Accent.TButton").grid(row=1, column=col, columnspan=2, padx=5, pady=10, sticky="ew")

        self.tree = ttk.Treeview(self.main_frame, 
                                columns=("ID", "Name", "Quantity", "Price", "Min Stock"), 
                                show="headings")
        self.tree.grid(row=1, column=0, sticky="nsew", pady=5)
        
        self.tree.heading("ID", text="ID")
        self.tree.heading("Name", text="Name")
        self.tree.heading("Quantity", text="Quantity")
        self.tree.heading("Price", text="Price")
        self.tree.heading("Min Stock", text="Min Stock")
        
        self.tree.column("ID", width=50, stretch=True)
        self.tree.column("Name", width=200, stretch=True)
        self.tree.column("Quantity", width=100, stretch=True)
        self.tree.column("Price", width=100, stretch=True)
        self.tree.column("Min Stock", width=100, stretch=True)
        
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        
        self.refresh_inventory()

    def on_tree_select(self, event):
        selected = self.tree.selection()
        if selected:
            item = self.tree.item(selected[0])
            values = item['values']
            self.name_entry.delete(0, tk.END)
            self.quantity_entry.delete(0, tk.END)
            self.price_entry.delete(0, tk.END)
            self.min_stock_entry.delete(0, tk.END)
            
            self.name_entry.insert(0, values[1])
            self.quantity_entry.insert(0, values[2])
            self.price_entry.insert(0, values[3])
            self.min_stock_entry.insert(0, values[4])

    def validate_input(self, name, quantity, price, min_stock):
        if not name or not quantity or not price or not min_stock:
            return False, "All fields are required"
        if not re.match("^[a-zA-Z0-9 ]+$", name):
            return False, "Name should only contain letters, numbers, and spaces"
        try:
            qty = int(quantity)
            prc = float(price)
            min_stk = int(min_stock)
            if qty < 0 or prc < 0 or min_stk < 0:
                return False, "Values cannot be negative"
        except ValueError:
            return False, "Quantity and Min Stock must be integers, Price must be a number"
        return True, ""

    def add_product(self):
        name = self.name_entry.get()
        quantity = self.quantity_entry.get()
        price = self.price_entry.get()
        min_stock = self.min_stock_entry.get()
        
        is_valid, message = self.validate_input(name, quantity, price, min_stock)
        if not is_valid:
            messagebox.showerror("Error", message)
            return
        
        cursor = self.conn.cursor()
        cursor.execute("INSERT INTO products (name, quantity, price, min_stock) VALUES (%s, %s, %s, %s)",
                      (name, int(quantity), float(price), int(min_stock)))
        product_id = cursor.lastrowid
        
        cursor.execute("INSERT INTO transactions (product_id, type, quantity, date) VALUES (%s, %s, %s, %s)",
                      (product_id, "ADD", int(quantity), datetime.now()))
        self.conn.commit()
        
        self.clear_entries()
        self.refresh_inventory()

    def update_product(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a product")
            return
        
        item = self.tree.item(selected[0])
        product_id = item['values'][0]
        
        name = self.name_entry.get()
        quantity = self.quantity_entry.get()
        price = self.price_entry.get()
        min_stock = self.min_stock_entry.get()
        
        is_valid, message = self.validate_input(name, quantity, price, min_stock)
        if not is_valid:
            messagebox.showerror("Error", message)
            return
        
        cursor = self.conn.cursor()
        cursor.execute("UPDATE products SET name=%s, quantity=%s, price=%s, min_stock=%s WHERE id=%s",
                      (name, int(quantity), float(price), int(min_stock), product_id))
        
        cursor.execute("INSERT INTO transactions (product_id, type, quantity, date) VALUES (%s, %s, %s, %s)",
                      (product_id, "UPDATE", int(quantity), datetime.now()))
        self.conn.commit()
        
        self.clear_entries()
        self.refresh_inventory()

    def delete_product(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a product")
            return
        
        if messagebox.askyesno("Confirm", "Are you sure you want to delete this product?"):
            product_id = self.tree.item(selected[0])['values'][0]
            cursor = self.conn.cursor()
            cursor.execute("DELETE FROM transactions WHERE product_id=%s", (product_id,))
            cursor.execute("DELETE FROM products WHERE id=%s", (product_id,))
            self.conn.commit()
            self.refresh_inventory()

    def generate_report(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT name, quantity, min_stock FROM products WHERE quantity < min_stock")
        low_stock = cursor.fetchall()
        
        report_window = tk.Toplevel(self.root)
        report_window.title("Inventory Report")
        report_window.geometry("400x300")
        report_window.configure(bg="#ECEFF1")
        
        report_window.grid_rowconfigure(0, weight=0)
        report_window.grid_rowconfigure(1, weight=1)
        report_window.grid_columnconfigure(0, weight=1)
        
        ttk.Label(report_window, text="Low Stock Report", 
                 style="Report.TLabel").grid(row=0, column=0, pady=10, sticky="ew")
        style = ttk.Style()
        style.configure("Report.TLabel", background="#ECEFF1", font=("Poppins", 18, "bold"), 
                       foreground="#263238")
        style.configure("Treeview", background="#FFFFFF", foreground="#263238", 
                       fieldbackground="#FFFFFF", font=("Poppins", 12))
        style.configure("Treeview.Heading", background="#B0BEC5", foreground="#263238", 
                       font=("Poppins", 14, "bold"))
        
        tree = ttk.Treeview(report_window, columns=("Name", "Quantity", "Min Stock"), show="headings")
        tree.grid(row=1, column=0, sticky="nsew")
        
        tree.heading("Name", text="Name")
        tree.heading("Quantity", text="Current Qty")
        tree.heading("Min Stock", text="Min Stock")
        
        tree.column("Name", width=200, stretch=True)
        tree.column("Quantity", width=100, stretch=True)
        tree.column("Min Stock", width=100, stretch=True)
        
        for item in low_stock:
            tree.insert("", "end", values=item)

    def refresh_inventory(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM products")
        for row in cursor.fetchall():
            self.tree.insert("", "end", values=row)

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.quantity_entry.delete(0, tk.END)
        self.price_entry.delete(0, tk.END)
        self.min_stock_entry.delete(0, tk.END)

    def __del__(self):
        self.conn.close()

if __name__ == "__main__":
    root = tk.Tk()
    app = InventoryManagementSystem(root)
    root.mainloop()
